<?php
    include_once 'php/test.php';
?>

<!DOCTYPE html> 
<html>
<head>
<title></title>
<body>

$conn;

</body>
</html>
